from app.models.user import User
from app.models.diagnosis import Diagnosis
